Two Php files named mac.php and orders.php
mac.php: main page which allows users to add products to cart and allows them to place order.
orders.php: order placing page which allows the users with existing user id to submit the order and new users to register and place the order.
It also gives the order summary.

Two DB tables
customer has details of customers who registered.
orders has details of the customers who placed the order with the product details.

Please use existing customer is as 4 and run the code.
